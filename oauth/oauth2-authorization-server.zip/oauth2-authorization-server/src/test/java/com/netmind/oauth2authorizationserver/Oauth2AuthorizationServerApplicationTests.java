package com.netmind.oauth2authorizationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2AuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
