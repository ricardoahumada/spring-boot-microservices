INSERT INTO products (name, serial) VALUES
('Magazine','111-222-3333'),
('Toothpaste','222-333-4444'),
('Travel','333-444-5555'),
('Candy','444-555-6666'),
('Book','555-666-3333');