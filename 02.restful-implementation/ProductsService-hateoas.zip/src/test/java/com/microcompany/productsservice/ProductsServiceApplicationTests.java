package com.microcompany.productsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
